use serde;
use csv;
use std::fs;

fn main() {
  let mut file = OpenOptions::new()
    .read(true)
    .write(true)
    .open("src/968560_33.65_-84.46_2022.csv")
    .expect("file.txt doesn't exist or so");

  let mut lines = BufReader::new(file).lines().skip(2)
    .map(|x| x.unwrap())
    .collect::<Vec<String>>().join("\n");

  dbg!(lines);
  let mut rdr = ReaderBuilder::new()
  .delimiter(b';')
  .from_reader(lines.as_bytes());
  
  dbg!(rdr);
  
  println!("Hello, world!");
}


/// Simulate the energy production and consumption of a plant and its CO2 production. 
/// Use data from real sources
/// 
/// 

/// Calculate the cost, CO2 production, and energy failures of a plant.

struct HistoricalData {
  data: Vec<DataPoints>
}

struct DataPoint {
  date_time: Time,
  wind_speed: f32,
  solar_iradiance: f32,
  energy_demand: f32,
  cloud_cover: f32,
  temperature: f32,
}


struct Plant {
  solar_panels: f32,
  wind_turbines: f32,
  coal_power_plants: f32,
  hydro_power_plants: f32,
  nuclear_power_plants: f32,
  battery_storage: f32,
}

struct SimulationResult {
  demand_met: f32,
  demand_not_met: f32,
  overflow: f32,
  co2_emissions: f32,
  energy_failures: f32,
}

#[derive(Debug, serde::Deserialize)]
struct Record {
  Year: i32,
  Month: i32,
  Day: i32,
  Hour: i32,
  Minute: i32,
  Temperature: f32,
  Clearsky_DHI: f32,
  Clearsky_DNI: f32,
  Clearsky_GHI: f32,
  Cloud_Type: f32,
  Dew_Point: f32,
  DHI: f32,
  DNI: f32,
  Fill_Flag: f32,
  GHI: f32,
  Relative_Humidity: f32,
  Solar_Zenith_Angle: f32,
  Surface_Albedo: f32,
  Pressure: f32,
  Precipitable_Water: f32,
  Wind_Direction: f32,
  Wind_Speed: f32,
  #[serde(rename="Global Horizontal UV Irradiance (280-400nm)")]
  Global_Horizontal_UV_Irradiance28_400nm: f32,
  #[serde(rename="Global Horizontal UV Irradiance (295-385nm)")]
  Global_Horizontal_UV_Irradiance_295_385nm: f32
}

fn solar_prod(solar_radiance: f32, efficency: f32, capacity: f32, time_hours: f32) -> f32 {
  let solar_prod = (solar_radiance * efficency * capacity * time_hours);
  return solar_prod;
}

impl Plant {
  fn simulate(&self, hist: HistoricalData) -> SimulationResult {
    let battery_charge = 0;

    for dp in hist {
      let solar_power = dp.solar_iradiance * self.solar_panels;
      let wind_power = dp.wind_speed * self.wind_turbines;
      
    }

    todo!()
  }
}